
<p align="center">
  <a href="http://leeyom.top"><img src="http://image.leeyom.top/20171225151421354757669.png" alt="Leeyom的个人站"></a>
</p>

<p align="center">
  <a href="#"><img src="https://img.shields.io/badge/%E5%86%99%E4%BD%9C%E5%B7%A5%E5%85%B7-MWeb-red.svg" alt=""></a>
  <a href="#"><img src="https://travis-ci.org/Alamofire/Alamofire.svg?branch=master" alt=""></a>
  <a href="#"><img src="https://img.shields.io/packagist/l/doctrine/orm.svg" alt="LICENSE"></a>
  <a href="#"><img src="https://img.shields.io/badge/platform-OSX%7CWin%7CLinux-blue.svg" alt=""></a>
  <a href="#"><img src="https://badges.frapsoft.com/os/v1/open-source.svg?v=103" alt=""></a>   	
  <a href="#"><img src="https://img.shields.io/badge/framework-hexo-orange.svg" alt=""></a>  
</p>

## 目的

分享，记录，开源，总结。

## 框架

采用快速、简洁且高效的博客框架-[Hexo](https://hexo.io/zh-cn/)。

## 主题

- 由于spfk主题的图片缩放有问题，文章不好排版，所以换回了[NexT](https://github.com/iissnan/hexo-theme-next)主题。

## 评论

- 评论系统已切换为[Valine](https://valine.js.org/)。

## 图床

现阶段采用的是[七牛云](https://portal.qiniu.com/)，已经备案了，将图片上传到七牛云的对象存储中，工具使用[PicGo](https://github.com/Molunerfinn/PicGo)。

## 新站点

后期新的文章准备都放到这个仓库[issue](https://github.com/superleeyom/blog)，旧站点后期不再更新，但是会保留。


